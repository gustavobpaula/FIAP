package gustavo.projetomob;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class CanvasActivity extends AppCompatActivity {

    private ImageView imgRsoto;
    private boolean piscou;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_canvas);
        imgRsoto = (ImageView) findViewById(R.id.imgRosto);

        desenharNormal();
    }

    public void desenharNormal(){

        Bitmap bmp = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();
        p.setColor(Color.YELLOW);
        Paint p2 = new Paint();
        p2.setColor(Color.BLACK);
        c.drawCircle(50, 50, 30, p);
        c.drawLine(40, 70, 60, 70, p2);

        c.drawCircle(40, 40, 5, p2);
        c.drawCircle(60, 40, 5, p2);
        imgRsoto.setImageBitmap(bmp);

    }

    public void desenharPiscado(){

        Bitmap bmp = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint();
        p.setColor(Color.YELLOW);
        Paint p2 = new Paint();
        p2.setColor(Color.BLACK);
        c.drawCircle(50, 50, 30, p);
        c.drawLine(40, 70, 60, 70, p2);

        c.drawCircle(40, 40, 5, p2);
        c.drawLine(55, 40, 65, 40, p2);
        imgRsoto.setImageBitmap(bmp);

    }

    public void piscar(View v){

        if(piscou){
            desenharNormal();
        }else{
            desenharPiscado();
        }

        piscou = !piscou;
    }
}
