package gustavo.projetomob;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class ActivityB extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        if (savedInstanceState != null) {
            Log.i("ESTADO", savedInstanceState.getString("teste"));
        }
    }

    protected void onSaveInstanceState(Bundle outState){
        outState.putString("teste", "Meu teste...");
        Log.i("ESTADO", "Salvando estado...");
        super.onSaveInstanceState(outState);
    }

    public void proxima(View v) throws Throwable {
        Intent i = new Intent(this, ActivityC.class);
        startActivity(i);
        finalize();
    }


}
