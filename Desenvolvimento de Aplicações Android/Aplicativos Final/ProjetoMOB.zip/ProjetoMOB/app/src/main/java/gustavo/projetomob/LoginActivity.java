package gustavo.projetomob;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText email;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void login(View view) {
        email = (EditText) findViewById(R.id.edtEmail);
        password = (EditText) findViewById(R.id.edtPassword);

        Intent intent = new Intent(this, ValidaLoginActivity.class);
        intent.putExtra("email", email.getText().toString());
        intent.putExtra("password", password.getText().toString());

        startActivityForResult(intent, 1);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK && requestCode == 1){
            if(data.hasExtra("retorno")){
                Toast.makeText(this, data.getExtras().getString("retorno"), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://google.com.br"));
                startActivity(i);
            }
        }else{
            if(data.hasExtra("retorno")){
                Toast.makeText(this, data.getExtras().getString("retorno"), Toast.LENGTH_SHORT).show();
                email.getText().clear();
                password.getText().clear();
            }
        }
    }
}
