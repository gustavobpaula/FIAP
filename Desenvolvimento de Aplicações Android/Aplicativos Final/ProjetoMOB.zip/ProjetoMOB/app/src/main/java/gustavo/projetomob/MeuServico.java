package gustavo.projetomob;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * Created by Gustavo on 22/07/2016.
 */
public class MeuServico extends Service {
    @Override
    public IBinder onBind(Intent arg0){
        return null;
    }

    @Override
    public int onStartCommand (Intent intent, int flags, int startid){
        Log.i("Meu Serviço", "Serviço Iniciando...");
        return START_STICKY;
    }
}
