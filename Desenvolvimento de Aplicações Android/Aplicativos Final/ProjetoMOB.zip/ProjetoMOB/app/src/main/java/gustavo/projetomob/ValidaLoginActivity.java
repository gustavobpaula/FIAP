package gustavo.projetomob;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class ValidaLoginActivity extends AppCompatActivity {

    private String msg;
    private int resultado = RESULT_CANCELED;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle param = getIntent().getExtras();
        String email = param.getString("email");
        String password = param.getString("password");

        if (validaLogin(email, password)){
            resultado = RESULT_OK;
            msg = "Sucesso!";
        }else{
            resultado = RESULT_CANCELED;
            msg = "Dados Inválidos";
        }

        finish();
    }

    private boolean validaLogin(String email, String password){
        if( email != null && email.equalsIgnoreCase("gustavo@jussi.com.br")
                && password != null && password.equals("teste") ){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public void finish() {
        Intent ret = new Intent();
        ret.putExtra("retorno", msg);
        setResult(resultado, ret);
        super.finish();
    }
}
