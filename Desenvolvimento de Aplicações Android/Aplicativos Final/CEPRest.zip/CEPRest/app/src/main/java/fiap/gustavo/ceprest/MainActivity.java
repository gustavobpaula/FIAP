package fiap.gustavo.ceprest;

import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private Button btnBuscar;
    private EditText txtCEP;
    private EditText txtLogradouro;
    private EditText txtComplemento;
    private EditText txtBairro;
    private EditText txtLocalidade;
    private EditText txtUf;
    private EditText txtIbge;
    private EditText txtGia;
    private ViaCEP vCEP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.btnBuscar = (Button) findViewById(R.id.btnBuscar);
        this.txtCEP = (EditText) findViewById(R.id.txtCEP);
        this.txtLogradouro = (EditText) findViewById(R.id.txtLogradouro);
        this.txtComplemento = (EditText) findViewById(R.id.txtComplemento);
        this.txtBairro = (EditText) findViewById(R.id.txtBairro);
        this.txtLocalidade = (EditText) findViewById(R.id.txtLocalidade);
        this.txtUf = (EditText) findViewById(R.id.txtUf);
        this.txtIbge = (EditText) findViewById(R.id.txtIbge);
        this.txtGia = (EditText) findViewById(R.id.txtGia);

    }

    public void buscarCep(View view) {

        if (view == this.btnBuscar) {

            ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

            if (networkInfo != null && networkInfo.isConnected()) {
                // limpa
                this.txtBairro.setText("");
                this.txtComplemento.setText("");
                this.txtGia.setText("");
                this.txtIbge.setText("");
                this.txtLocalidade.setText("");
                this.txtLogradouro.setText("");
                this.txtUf.setText("");

                // cep
                String cep = this.txtCEP.getText().toString();

                // verifica se o CEP Ã© vÃ¡lido
                Pattern pattern = Pattern.compile("^[0-9]{5}-[0-9]{3}$");
                Matcher matcher = pattern.matcher(cep);

                if (matcher.find()) {
                    new DownloadCEPTask().execute(cep);
                } else {
                    //JOptionPane.showMessageDialog(null, "Favor informar um CEP válido!", "Aviso!", JOptionPane.WARNING_MESSAGE);
                    new AlertDialog.Builder(this)
                            .setTitle("Aviso!")
                            .setMessage("Favor informar um CEP válido!")
                            .setPositiveButton(R.string.msgOk, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // nada
                                }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Sem Internet!")
                        .setMessage("NÃ£o tem nenhuma conexÃ£o de rede disponÃ­vel!")
                        .setPositiveButton(R.string.msgOk, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // nada
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        }
    }


    private class DownloadCEPTask extends AsyncTask<String, Void, ViaCEP> {

        protected ViaCEP doInBackground(String... ceps) {
            ViaCEP vCep = null;

            try {
                vCep = new ViaCEP(ceps[0]);
            } finally {
                return vCep;
            }
        }

        @Override
        protected void onPostExecute(ViaCEP result) {
            if (result != null) {
                txtBairro.setText(result.getBairro());
                txtComplemento.setText(result.getComplemento());
                txtGia.setText(result.getGia());
                txtIbge.setText(result.getIbge());
                txtLocalidade.setText(result.getLocalidade());
                txtLogradouro.setText(result.getLogradouro());
                txtUf.setText(result.getUf());
            }
        }
    }
}
