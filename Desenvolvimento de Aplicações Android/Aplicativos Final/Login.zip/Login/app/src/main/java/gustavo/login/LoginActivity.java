package gustavo.login;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    private EditText edtUser;
    private EditText edtPassword;
    private EditText edtDateBirth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

    }

    public void openDatePicker(View v){
        DialogFragment newFragment = new DateFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void validaLogin(View v){
        edtUser = (EditText) findViewById(R.id.edtUser);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtDateBirth = (EditText) findViewById(R.id.edtDateBirth);

        Intent intent = new Intent(this, ValidaLoginService.class);

        intent.putExtra("user", edtUser.getText().toString());
        intent.putExtra("password", edtPassword.getText().toString());
        intent.putExtra("dateBirth", edtDateBirth.getText().toString());

        startService(intent);
        stopService(intent);
    }

}
