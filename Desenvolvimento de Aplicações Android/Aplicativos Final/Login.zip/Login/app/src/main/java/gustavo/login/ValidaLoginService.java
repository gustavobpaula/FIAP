package gustavo.login;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class ValidaLoginService extends Service {
    private Bundle param;
    private String user;
    private String password;
    private String dateBirth;
    public ValidaLoginService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand (Intent intent, int flags, int startid) {
        Log.i("ValidaLoginService", "Serviço iniciado...");

        param = intent.getExtras();
        user = param.getString("user");
        password = param.getString("password");
        dateBirth = param.getString("dateBirth");

        Log.i("usuário",user);
        Log.i("senha",password);
        Log.i("data de nascimento",dateBirth);

        if (validaLogin(user, password, dateBirth)){
            sendNotification("Login realizado com Sucesso!");
        }else{
            sendNotification("Falha ao realizar Login!");
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        Log.i("ValidaLoginService", "Serviço encerrado...");
    }

    private boolean validaLogin(String email, String password, String dateBirth){
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");



        try{
            Date userDate = formatter.parse(dateBirth);

            int age = getAge(userDate);

            Log.i("Idade do usuário é ", Integer.toString(age));

            if( email != null && email.equalsIgnoreCase("ps@fiap.com.br")
                    && password != null && password.equals("10")
                    && age >= 18){
                return true;
            }else{
                return false;
            }

        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getAge (Date userDate) {
        int age;

        Calendar dateUser = Calendar.getInstance();
        Calendar datePresent = Calendar.getInstance();

        dateUser.setTime(userDate);
        datePresent.setTime(Calendar.getInstance().getTime());

        int presentYear = datePresent.get(Calendar.YEAR);
        int presentMonth = datePresent.get(Calendar.MONTH);
        int presentDay = datePresent.get(Calendar.DAY_OF_MONTH);

        age = presentYear - dateUser.get(Calendar.YEAR);
        if ((presentMonth < dateUser.get(Calendar.MONTH))
                || ((presentMonth == dateUser.get(Calendar.MONTH)) && (presentDay < dateUser
                .get(Calendar.DAY_OF_MONTH)))) {
            --age;
        }
        if(age < 0)
            throw new IllegalArgumentException("Age < 0");
        return age;
    }

    private void sendNotification(String message){
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);

        mBuilder.setContentTitle("Validação de Login");
        mBuilder.setContentText(message);
        mBuilder.setSmallIcon(R.drawable.lock);
        mBuilder.setAutoCancel(true);
        mBuilder.setContentIntent(PendingIntent.getActivity(this, 0,
                new Intent(this, LoginActivity.class), PendingIntent.FLAG_UPDATE_CURRENT));

        Notification notification = mBuilder.build();
        notification.vibrate = new long[]{150, 300, 150, 600};

        mNotificationManager.notify(100, notification);

        Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone toque = RingtoneManager.getRingtone(this, som);
        toque.play();
    }
}
