package gustavo.projetomob2;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;


//SHARED PREFERENCES AND FILE

public class LoginActivity extends AppCompatActivity {

    private EditText edtUser;
    private EditText edtPassword;
    private CheckBox cbConected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtUser = (EditText) findViewById(R.id.edtLogin);
        edtPassword = (EditText) findViewById(R.id.edtPassword);

        // pega o login pelo SharedPreferences
        SharedPreferences sp = getPreferences(MODE_PRIVATE);

        String loginSP = sp.getString("username", null);
        String passwordSP = sp.getString("password", null);

        //pega o login pelo File
        String txt = null;
        try {
            FileInputStream fis = openFileInput("login.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            txt = br.readLine();
            fis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        if (loginSP != null && passwordSP != null){
            edtUser.setText(loginSP);
            edtPassword.setText(passwordSP);
        }else {
            if (txt != null) {
                Log.i("Texto completo", txt);
                String test = txt;
                String parts[] = txt.split("\\|");
                Log.i("Usuário", parts[0]);
                Log.i("Senha", parts[1]);
                edtUser.setText(parts[0].toString());
                edtPassword.setText(parts[1].toString());
            }
        }
    }

    public void loginWithSharedPreferences(View v){
        edtUser = (EditText) findViewById(R.id.edtLogin);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        cbConected = (CheckBox) findViewById(R.id.cbConected);

        SharedPreferences sp = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();

        if(cbConected.isChecked()){
            e.putString("username", edtUser.getText().toString());
            e.putString("password", edtPassword.getText().toString());
        }else{
            e.clear();
        }

        e.commit();
        finish();
    }

    public void loginWithFiles(View v) throws IOException {

        edtUser = (EditText) findViewById(R.id.edtLogin);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        cbConected = (CheckBox) findViewById(R.id.cbConected);


        if(cbConected.isChecked()){
            try {
                FileOutputStream fos = openFileOutput("login.txt", MODE_PRIVATE);
                String txt = edtUser.getText().toString() + "|" + edtPassword.getText().toString();
                fos.write(txt.getBytes());
                fos.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            FileOutputStream fos = openFileOutput("login.txt", MODE_PRIVATE);
            File f = new File(System.getProperty("user.dir"),"login.txt");
            fos.close();
            f.delete();
        }


        finish();


    }
}
